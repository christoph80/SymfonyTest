<div id="cacheablePartialVarParam"><?php include_partial('cache/cacheablePartial', array('varParam' => 'varParam', 'sf_cache_key' => 'cacheablePartial')) ?></div>
<div id="contextualCacheablePartialVarParam"><?php include_partial('cache/contextualCacheablePartial', array('varParam' => 'varParam', 'sf_cache_key' => 'contextualCacheablePartial')) ?></div>

<div id="cacheableComponentVarParam"><?php include_component('cache', 'cacheableComponent', array('varParam' => 'varParam', 'sf_cache_key' => 'cacheableComponent')) ?></div>
<div id="contextualCacheableComponentVarParam"><?php include_component('cache', 'contextualCacheableComponent', array('varParam' => 'varParam', 'sf_cache_key' => 'contextualCacheableComponent')) ?></div>
