<form action="" method="post">
  <table>
    <?php echo $form ?>
    <tr>
      <td colspan="2">
        <input type="submit" value="submit" />
      </td>
    </tr>
  </table>
</form>
